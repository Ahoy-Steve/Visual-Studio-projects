﻿namespace Poze_Filme
{
    partial class filme
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(filme));
            this.cautaFisier = new System.Windows.Forms.OpenFileDialog();
            this.wmp = new AxWMPLib.AxWindowsMediaPlayer();
            this.listafilme = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.wmp)).BeginInit();
            this.SuspendLayout();
            // 
            // cautaFisier
            // 
            this.cautaFisier.FileName = "cautaFisier";
            this.cautaFisier.FileOk += new System.ComponentModel.CancelEventHandler(this.OpenFileDialog1_FileOk);
            // 
            // wmp
            // 
            this.wmp.Enabled = true;
            this.wmp.Location = new System.Drawing.Point(180, 12);
            this.wmp.Name = "wmp";
            this.wmp.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("wmp.OcxState")));
            this.wmp.Size = new System.Drawing.Size(645, 426);
            this.wmp.TabIndex = 1;
            // 
            // listafilme
            // 
            this.listafilme.FormattingEnabled = true;
            this.listafilme.Location = new System.Drawing.Point(12, 12);
            this.listafilme.Name = "listafilme";
            this.listafilme.Size = new System.Drawing.Size(162, 420);
            this.listafilme.TabIndex = 2;
            this.listafilme.SelectedIndexChanged += new System.EventHandler(this.Listafilme_SelectedIndexChanged);
            // 
            // filme
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(837, 450);
            this.Controls.Add(this.listafilme);
            this.Controls.Add(this.wmp);
            this.Name = "filme";
            this.Text = "filme";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Filme_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.wmp)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.OpenFileDialog cautaFisier;
        private AxWMPLib.AxWindowsMediaPlayer wmp;
        private System.Windows.Forms.ListBox listafilme;
    }
}