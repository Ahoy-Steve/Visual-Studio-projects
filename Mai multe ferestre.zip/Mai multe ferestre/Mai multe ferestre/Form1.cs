﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Mai_multe_ferestre
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Label1_Click(object sender, EventArgs e)
        {
            The_Trickster t = new The_Trickster();
            this.Hide();
            t.ShowDialog();
            t.Dispose();
            this.Show();
        }

        private void Label2_Click(object sender, EventArgs e)
        {
            Yun_Jin_Lee y = new Yun_Jin_Lee();
            this.Hide();
            y.ShowDialog();
            y.Dispose();
            this.Show();
        }
    }
}
