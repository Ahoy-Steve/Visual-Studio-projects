﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Maze_dubla2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            MoveToStart();
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void label26_Click(object sender, EventArgs e)
        {

        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            Form1.ActiveForm.Text = "X=" + e.X.ToString() + " Y=" + e.Y.ToString();
        }

        private void button1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.X < 2) button1.Left += e.X;
            if (e.X > button1.Width - 2) button1.Left -= button1.Width - e.X;
            if (e.Y < 2) button1.Top += e.Y;
            if (e.Y > button1.Height - 2) button1.Top -= button1.Height - e.Y;
        }

        private void pictureBox1_MouseEnter(object sender, EventArgs e)
        {
            MessageBox.Show("Bravo!");
            Close();
        }
        private void MoveToStart()
        {

            Point startingPoint = panel1.Location;
            startingPoint.Offset(30, 70);
            Cursor.Position = PointToScreen(startingPoint);
        }

        private void wall_MouseEnter(object sender, EventArgs e)
        {
            MoveToStart();
        }
    }
}
